package com.Forever.model;

import java.io.File;

public class Userhome {

	private int id;
	private int u_id;
	private int visitcount;
	private int listencount;
	private File pic;
	private String music;
	private String album;
	private File photo;
	private int Identity_tag;
	private int Style_tags;
	private String Stage_name;
	private String region;
	private String Personalized_signature;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getU_id() {
		return u_id;
	}
	public void setU_id(int u_id) {
		this.u_id = u_id;
	}
	public int getVisitcount() {
		return visitcount;
	}
	public void setVisitcount(int visitcount) {
		this.visitcount = visitcount;
	}
	public int getListencount() {
		return listencount;
	}
	public void setListencount(int listencount) {
		this.listencount = listencount;
	}
	public File getPic() {
		return pic;
	}
	public void setPic(File pic) {
		this.pic = pic;
	}
	public String getMusic() {
		return music;
	}
	public void setMusic(String music) {
		this.music = music;
	}
	public String getAlbum() {
		return album;
	}
	public void setAlbum(String album) {
		this.album = album;
	}
	public File getPhoto() {
		return photo;
	}
	public void setPhoto(File photo) {
		this.photo = photo;
	}
	public int getIdentity_tag() {
		return Identity_tag;
	}
	public void setIdentity_tag(int identity_tag) {
		Identity_tag = identity_tag;
	}
	public int getStyle_tags() {
		return Style_tags;
	}
	public void setStyle_tags(int style_tags) {
		Style_tags = style_tags;
	}
	public String getStage_name() {
		return Stage_name;
	}
	public void setStage_name(String stage_name) {
		Stage_name = stage_name;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getPersonalized_signature() {
		return Personalized_signature;
	}
	public void setPersonalized_signature(String personalized_signature) {
		Personalized_signature = personalized_signature;
	}
	
	
	
}
