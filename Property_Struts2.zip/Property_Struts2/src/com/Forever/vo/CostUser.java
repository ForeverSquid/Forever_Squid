package com.Forever.vo;

public class CostUser {

	private int dian;
	private String cdian_date;
	private int shui;
	private String cshui_date;
	private int re;
	private String cre_date;
	private int wygl ;
	private String cwygl_date;
	private int beizhu;
	public int getDian() {
		return dian;
	}
	public void setDian(int dian) {
		this.dian = dian;
	}
	public String getCdian_date() {
		return cdian_date;
	}
	public void setCdian_date(String cdian_date) {
		this.cdian_date = cdian_date;
	}
	public int getShui() {
		return shui;
	}
	public void setShui(int shui) {
		this.shui = shui;
	}
	public String getCshui_date() {
		return cshui_date;
	}
	public void setCshui_date(String cshui_date) {
		this.cshui_date = cshui_date;
	}
	public int getRe() {
		return re;
	}
	public void setRe(int re) {
		this.re = re;
	}
	public String getCre_date() {
		return cre_date;
	}
	public void setCre_date(String cre_date) {
		this.cre_date = cre_date;
	}
	public int getWygl() {
		return wygl;
	}
	public void setWygl(int wygl) {
		this.wygl = wygl;
	}
	public String getCwygl_date() {
		return cwygl_date;
	}
	public void setCwygl_date(String cwygl_date) {
		this.cwygl_date = cwygl_date;
	}
	public int getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(int beizhu) {
		this.beizhu = beizhu;
	}
	
	
}
