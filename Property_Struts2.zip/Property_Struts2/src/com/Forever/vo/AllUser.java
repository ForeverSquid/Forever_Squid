package com.Forever.vo;

import java.io.Serializable;

public class AllUser implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int dian;
	private String cdian_date;
	private int shui;
	private String cshui_date;
	private int re;
	private String cre_date;
	private int wygl ;
	private String cwygl_date;
	private int beizhu;
	private int danyuan;
	private String huzhu_name;
	private int renkou_count;
	private int area;
	private String password;
	public int getDian() {
		return dian;
	}
	public void setDian(int dian) {
		this.dian = dian;
	}
	public String getCdian_date() {
		return cdian_date;
	}
	public void setCdian_date(String cdian_date) {
		this.cdian_date = cdian_date;
	}
	public int getShui() {
		return shui;
	}
	public void setShui(int shui) {
		this.shui = shui;
	}
	public String getCshui_date() {
		return cshui_date;
	}
	public void setCshui_date(String cshui_date) {
		this.cshui_date = cshui_date;
	}
	public int getRe() {
		return re;
	}
	public void setRe(int re) {
		this.re = re;
	}
	public String getCre_date() {
		return cre_date;
	}
	public void setCre_date(String cre_date) {
		this.cre_date = cre_date;
	}
	public int getWygl() {
		return wygl;
	}
	public void setWygl(int wygl) {
		this.wygl = wygl;
	}
	public String getCwygl_date() {
		return cwygl_date;
	}
	public void setCwygl_date(String cwygl_date) {
		this.cwygl_date = cwygl_date;
	}
	public int getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(int beizhu) {
		this.beizhu = beizhu;
	}
	public int getDanyuan() {
		return danyuan;
	}
	public void setDanyuan(int danyuan) {
		this.danyuan = danyuan;
	}
	public String getHuzhu_name() {
		return huzhu_name;
	}
	public void setHuzhu_name(String huzhu_name) {
		this.huzhu_name = huzhu_name;
	}
	public int getRenkou_count() {
		return renkou_count;
	}
	public void setRenkou_count(int renkou_count) {
		this.renkou_count = renkou_count;
	}
	public int getArea() {
		return area;
	}
	public void setArea(int area) {
		this.area = area;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
