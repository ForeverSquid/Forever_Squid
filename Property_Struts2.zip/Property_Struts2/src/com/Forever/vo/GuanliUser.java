package com.Forever.vo;

public class GuanliUser {

	private String guanli_name;
	private String guanli_password;
	public String getGuanli_name() {
		return guanli_name;
	}
	public void setGuanli_name(String guanli_name) {
		this.guanli_name = guanli_name;
	}
	public String getGuanli_password() {
		return guanli_password;
	}
	public void setGuanli_password(String guanli_password) {
		this.guanli_password = guanli_password;
	}
	
	
}
