package com.Forever.vo;

public class MesUser {

	public int danyuan;
	public String time;
	public String mes;
	public String inf;
	
	
	public String getInf() {
		return inf;
	}
	public void setInf(String inf) {
		this.inf = inf;
	}
	public int getDanyuan() {
		return danyuan;
	}
	public void setDanyuan(int danyuan) {
		this.danyuan = danyuan;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getMes() {
		return mes;
	}
	public void setMes(String mes) {
		this.mes = mes;
	}
	
	
}
