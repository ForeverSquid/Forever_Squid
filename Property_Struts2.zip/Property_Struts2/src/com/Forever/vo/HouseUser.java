package com.Forever.vo;

public class HouseUser {

	private int danyuan;
	private String huzhu_name;
	private int renkou_count;
	private int area;
	private String password;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getDanyuan() {
		return danyuan;
	}
	public void setDanyuan(int danyuan) {
		this.danyuan = danyuan;
	}
	public String getHuzhu_name() {
		return huzhu_name;
	}
	public void setHuzhu_name(String huzhu_name) {
		this.huzhu_name = huzhu_name;
	}
	public int getRenkou_count() {
		return renkou_count;
	}
	public void setRenkou_count(int renkou_count) {
		this.renkou_count = renkou_count;
	}
	public int getArea() {
		return area;
	}
	public void setArea(int area) {
		this.area = area;
	}
	
	
}
